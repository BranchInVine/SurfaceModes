
***Name of the program: SurfaceModes

***Title of the manuscript: 
A versatile solver of the normal modes for horizontal stratified complicated models

*** Authors: Bo Wu, Xiaofei Chen
