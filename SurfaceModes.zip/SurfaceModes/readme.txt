
***Name of the program: SurfaceModes

***Title of the manuscript: 
A versatile solver of the normal modes for horizontal stratified complicated models

*** Authors: Bo Wu, Xiaofei Chen

*** If you have any problems when using the codes, please contact the first
author via VigorWU AT qq.com.
